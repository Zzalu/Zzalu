const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
    proxy: 'http://i8c109.p.ssafy.io:8080/',
    // proxy: 'http://localhost:8080/',
  }
})