<template>
  <div class='text-center-container '>
          <!-- 로고랑 제목 -->
        <img
          alt="Celebrate Cat"
          class="celebrate"
          src="../../../assets/celebrate.gif"
        />
    <div class="error-content-bold">비밀번호 변경 완료</div>
    <div class="error-content-bold">비밀번호가 성공적으로 변경되었습니다!</div>
    <button class='submit-button'>로그인 바로가기</button>
  </div>
</template>

<script>
export default {
  name: "ResetComplete"
}
</script>

<style lang="postcss" scoped>

</style>