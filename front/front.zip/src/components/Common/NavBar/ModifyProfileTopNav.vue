<template>
  <!-- 완료버튼있는 nav -->
  <div class="h-nav-height fixed inset-x-0 top-0 bg-white flex items-center justify-center dark:bg-zz-bd">
    <span class="inline-block px-4 absolute left-0">
      <font-awesome-icon icon="fa-solid fa-chevron-left" class="text-2xl dark:text-white" />
    </span>
    <span class="inline-block px-4 absolute right-0 text-zz-s dark:text-white"> 완료 </span>
  </div>
</template>

<script>
export default {
  name: 'CompleteTopNav',
};
</script>

<style></style>
