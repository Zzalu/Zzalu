<template>
  <div>
    내꺼 채팅 (나는 프로필 띄울필요 X)
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>