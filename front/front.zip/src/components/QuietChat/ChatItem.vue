<template>
  <div>
    프로필사진
    아이디
    이사람이 보낸 gif
  </div>
</template>

<script>
import { defineComponent } from '@vue/composition-api'

export default defineComponent({
  setup() {
    
  },
})
</script>

<style scoped>

</style>
