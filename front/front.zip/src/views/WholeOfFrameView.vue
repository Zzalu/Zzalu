<template>
  <!-- 역대 명예의 전당 -->
  <small-logo-top-nav></small-logo-top-nav>
  <title-competition-list></title-competition-list>
</template>

<script>
import SmallLogoTopNav from '@/components/Common/NavBar/SmallLogoTopNav.vue';
import TitleCompetitionList from '@/components/WholeOfFrame/TitleCompetitionList.vue';
export default {
  components: { SmallLogoTopNav, TitleCompetitionList },
};
</script>

<style></style>
