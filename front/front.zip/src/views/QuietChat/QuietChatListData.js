export default [
    {
        id : 1,
        name : '무한도전 고독방',
        content : '무한도전을 사랑하고 또 사랑하는 사람들',
        hashtag : ['#무한도전','#무도'],
        master : '문여경',
        like : 1042,
        Image : './assets/Infinite_Challenge.jpg',
        createdAt : 20220101,
        updatedAt : '방금'
    },
    {
        id : 2,
        name : '이재용 고독방',
        content : '그저 GOAT',
        hashtag : ['#삼성','#샘송','#재드래곤'],
        master : '재드래곤',
        like : 336,
        Image : './assets/Dragon.jpg',
        createdAt : 20221101,
        updatedAt : '30분전'
    },
    {
        id : 3,
        name : '뉴진스 고독방',
        content : '훌쩍 커버렸어 함께한 기억처럼 널 보는 내 마음은 어느새 여름 지나 가을 기다렸지 all this time Do you want somebody 노래가 끝나지 않아 버리는걸 끝나지 않는 MT',
        hashtag : ['#해린','#민지','#혜인','#다니엘','#하니','#내가만든쿠키','#Ditto'],
        master : 'NewJeans',
        Image : './assets/Newjeans.jpg',
        like : 772,
        createdAt : 20230110,
        updatedAt : '어제'
    },
    {
        id : 4,
        name : '도라에몽 고독방인데 이름이 굉장히 길어져버린 고독방 근데 더더 길다면',
        content : '진구야아앙~~~',
        hashtag : ['#도라에몽','#친구'],
        master : '김지오',
        like : 200,
        Image : 'assets/emong.jpg',
        createdAt : 20230109,
        updatedAt : '5시간전'
    },
    {
        id : 5,
        name : 'BTS 고독방',
        content : '당신이 아미라면',
        hashtag : ['#버터','#다이너마이트','#정국','#뷔','#지민','#슈가','#진','#RM','#제이홉','#방탄','#방탄소년단','#BTS','#morehashtag1','#morehashtag2','#morehashtag3','#morehashtag4'],
        master : 'ARMY',
        like : 123,
        Image : 'assets/BTS.jpg',
        createdAt : 20221209,
        updatedAt : '3일전'
    },
]